package net.javaguides.springboot.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import net.javaguides.springboot.service.EmployeeService;
import org.springframework.ui.Model;
import net.javaguides.springboot.model.Employee;
@Controller
public class MainController {
	
	@GetMapping("/login")
	public String login() {
		return "login";
	}
	
	
	/*
	 * @GetMapping("/") public String home() { return "index"; }
	 */
}
